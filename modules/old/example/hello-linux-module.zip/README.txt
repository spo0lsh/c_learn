See following url for building instructions
http://www.cyberciti.biz/tips/build-linux-kernel-module-against-installed-kernel-source-tree.html

